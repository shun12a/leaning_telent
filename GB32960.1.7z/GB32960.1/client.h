#ifndef _CLIENT_
#define _CLIENT_

#include <sys/types.h>
#include <sys/socket.h>
#include <assert.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include <sys/epoll.h>
#include <pthread.h>
#include <stdlib.h>

#define MAX_EVENT_NUMBER 1024

#define PLATFORM_ADDRESS "192.168.241.128"
#define PLATFORM_PORT 6600

struct tm
{
  int	tm_sec;
  int	tm_min;
  int	tm_hour;
  int	tm_mday;
  int	tm_mon;
  int	tm_year;
  int	tm_wday;
  int	tm_yday;
  int	tm_isdst;
#ifdef __TM_GMTOFF
  long	__TM_GMTOFF;
#endif
#ifdef __TM_ZONE
  const char *__TM_ZONE;
#endif
};

typedef struct {
	login_interval_time;

};


#if 0
int socket(int domain,int type,int protocol);
//创建套接字，domain指套接字的协议簇，type指套接字的服务类型，protocol指协议：0为默认协议


int bind(int sockfd,const struct sockaddr* addr,socklen_t addrlen);
//将sockfd与socket地址绑定
//sockfd是网络套接字描述符

int connect(int sockfd,const struct sockaddr* serv_addr,socklen_t addrlen);
//客户端和服务器建立连接


int close(int sockfd);
//关闭连接


ssize_t recv(int sockfd, void *buff, size_t len, int flags);
//读取sockfd上的数据,buff和len参数分别指定读缓冲区的位置和大小

ssize_t send(int sockfd, const void *buff, size_t len, int flags);
//往socket上写入数据，buff和len参数分别指定写缓冲区的位置和数据长度
#endif

#endif

