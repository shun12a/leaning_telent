#include "GB32960.h"
#include "client.h"
#include "common.h"

int getServerIP(int getIPByDomainName, char *ip, int ip_size, int *port, char *domainName)
{
    if(getIPByDomainName == 0){
        if((ip != NULL) && (port != NULL) && (ip_size >= 16)){
            uint8_t u8IPAndPort[6];
//            getPara(SERVER_IP_PORT_ID, u8IPAndPort, 6);
            memset(ip, 0, sizeof(ip));
            sprintf(ip, "%d.%d.%d.%d", u8IPAndPort[0], u8IPAndPort[1], u8IPAndPort[2], u8IPAndPort[3]);
            *port = (u8IPAndPort[4]<<8) + u8IPAndPort[5];
        }
    }
}

int socketConnect()
{
    int fd;
    char ServerIP[16] = {0};
    int port;
    struct sockaddr_in socketaddr;
    int socketfd;

#if 1
    //sleep used for waiting networking
    sleep(5);
    if(getServerIP(1, ServerIP, sizeof(ServerIP), NULL, (char *)"rmweb.gzchangjiangev.com") == -1)
        return -1;
    port = 8899;
    printf("jason add ServerIP:%s port =%d \n",ServerIP,port);
#endif

    memset(&socketaddr, 0, sizeof(socketaddr));
    
#if 0
   socketaddr.sin_family = AF_INET;
	socketaddr.sin_port = htons(PORT);
	socketaddr.sin_addr.s_addr = inet_addr(IP);
#else
	socketaddr.sin_family = AF_INET;
//	socketaddr.sin_port = htons(8877);
	socketaddr.sin_port = htons(port);  //fpp 191107
	socketaddr.sin_addr.s_addr = inet_addr(ServerIP);
#endif
    if((socketfd = socket(AF_INET, SOCK_STREAM, 0)) != -1){
        GBTLOG("socketfd:%d\n",socketfd);
        printf("add server connect \r\n");
        if (connect(socketfd, (struct sockaddr*) &socketaddr, sizeof(socketaddr)) != -1){
            GBTLOG("Connect to server successfully,server IP:%s,PORT:%d\n",inet_ntoa(socketaddr.sin_addr),ntohs(socketaddr.sin_port));
            time_t tmp_time;
            struct tm *p_tm = NULL;
            tmp_time = time(NULL);
            p_tm = gmtime(&tmp_time);
        }
    }
}
