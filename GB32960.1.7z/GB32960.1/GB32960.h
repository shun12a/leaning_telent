#ifndef _GB32960_
#define _GB32960_

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <error.h>
 
#define SERVER_IP  "112.74.171.112"
#define PARAMETER_INFO_PATH "/data/GB32960Para"
#define DELETE_PARAMETER "rm -rf /data/GB32960Para"

#define _PACK_START __attribute__((__packed__))

#define SERVER_PORT  8877
#define DATA_BUFF_LEN 1024
#define GBT32960_PROTOCOL_HEADER 0x2323
#define CLOUDPKG_MAXSIZE 2048

#define VINCODE_SIZE 17
#define DATA_SIZE_MAX 65531
bool reissue = false;

#define CLOUDMSG_SIZE(datasize) (2 + 2 + VINCODE_SIZE + 3 + \
datasize + 1)
#define CLOUDMSG_BCCSIZE(datasize) (2 + VINCODE_SIZE + 3 + \
datasize)

//数据包结构和定义
typedef struct _PACK_START
{
	uint8_t head[2]; //
	uint8_t amd;																								//命令标识
	uint8_t ack;																								//应答标识
//size 4
	uint8_t vincode[VINCODE_SIZE];
	uint8_t encryptmode;																				//数据加密方式
	uint16_t datalen;																						//数据单元长度
//uint8_t nextmsg[0];																									//变长结构体
//size 3
//uint8_t data[CLOUDPKG_MAXSIZE - CLOUDMSG_SIZE(0)];					数据单元
//uint8_t bcc;																								校验码
}cloudmsg_t;

uint8_t *pack_Assembly(uint8_t *, void *, uint16_t *);

//拼装结构体
typedef struct _PACK_START
{
	cloudmsg_t pkg;
	uint16_t datalen;				//数据加密方式
	uint8_t mem[CLOUDPKG_MAXSIZE];
	uint8_t bcc;
}cloudpkg_t;



//命令标识定义
typedef enum
{
	CMD_VEH_SIGNIN = 0x01,								//车辆登入
	CMD_RT_UPLOAD = 0x02,									//实时信息上报
	CMD_FIX_UPLOAD = 0x03,								//补发信息上报
	CMD_VEH_SIGNOUT = 0x04,								//车辆登出
	CMD_PLT_SIGNIN = 0x05,								//平台登入
	CMD_PLT_SIGNOUT = 0x06,								//平台登出
	CMD_EP_RESV0 = 0x09,									//上行数据系统预留
	//RESV to 0x7f
	CMD_VEH_ENROLL = 0x71,								//注册指令
	CMD_STATE_UP = 0x72,									//终端状态上报
	CMD_TEST_MESS_UP = 0x73,							//平台文本信息透传上传
	
	CMD_ARGUMENT_STATUE_QUERY = 0x80,			//参数和状态查询
	CMD_SET_ARGUMENT = 0x81,							//设置参数
	CMD_VEH_CONTROL = 0x82,								//车载终端控制
	//RESV to 0x82
	CMD_DOWNLOAD_RESV = 0x83,							//下行数据系统预留
	//DOWNLOAD_RESV to 0xBF
	CMD_PLT_RESV = 0xC0,									//平台文本信息透传下发
	//REsV to 0xFE
	CMD_END = 0xFF												//结束
}cloudcmd_t;

//注册数据格式
typedef struct _PACK_START
{
	uint8_t MANA_NO[5];										//厂商编号
	unsigned char model[20];										//型号
	unsigned char terminal_num[12];							//终端编号
	unsigned char terminal_sw_ver[5];					//终端软件版本号
	unsigned char terminal_hd_ver[5];						//终端硬件版本
}cloud_sign_cmd;

#define DNS_IP_ARGUMENT 4
//注册应答
typedef struct _PACK_START
{
	uint8_t value_login;									//注册结果
	uint8_t DNS_length;										//域名长度
	uint8_t DNS_IP[DNS_IP_ARGUMENT];			//域名
	uint16_t connect_port;								//端口
	uint8_t connect_type;									//连接方式
	uint8_t ver_num[17];									//车架号
	uint16_t proto_num;										//协议编号
	uint16_t proto_ver;										//协议版本
	uint16_t temperature_probe;						//温度探针数
	uint16_t voltage_probe;								//电压探针数
	uint8_t boter1;												//CAN1波特率
	uint8_t boter2;												//CAN2波特率
	uint8_t iccid_nu[20];									//ICCID号
}login_reserve;



//终端状态上报指令
typedef struct _PACK_START 
{
	uint8_t GNSS_state;										//GNSS状态
	uint8_t longitude_latitude;						//经纬度
	uint8_t platform_time[2];							//企业平台离线时间
	uint8_t can_bus_state;								//CAN总线状态
	uint8_t store_state;									//存储状态
	uint8_t cmc_state;										//通信状态
	uint8_t external_state[3];						//外部硬件状态
}terminal_status_report;

//应答标识定义
typedef enum
{
	ACK_OK =0x01, ACK_ERR = 0x02, ACK_DUPVIN = 0x03, ACK_CMD = 0xFE
}cloudack_t;

//数据加密方式
typedef enum
{
	DAT_CRIPT_NONE = 0x01,
	DAT_CRIPT_RSA = 0x02,
	DAT_CRIPT_AES128 = 0x03,
	DAT_CRIPT_ERR = 0xFE
}cloudencript_t;

//基础时间
typedef struct _PACK_START
{
	//use GMT +8 Beijing Time
	uint8_t year;
	uint8_t mon;
	uint8_t day;
	uint8_t hour;
	uint8_t min;
	uint8_t sec
}cloudtime_t;

#define BATTERY_CNTMAX	48																					//可充电储能系统编码长度
#define BATTERY_CODEMAX	4																						//可充电储能子系统数
#define ICCID_SIZE			20
#define CLOUDMSG_VEN_SIGNIN_SIZE(batcnt, batsize) (batcnt * batsize + 2 + ICCID_SIZE + 8)
#define CLOUDmSG_VEHICLE_SIGNIN_PACK(out, src, size) (out = &src; size = CLOUDMSG_VEN_SIGNIN_SIZE(src->batterycnt, src->batterycodesize);)
//车辆登入
typedef struct _PACK_START
{
	cloudmsg_t head;
	cloudtime_t curtime;
	uint16_t seq;																							//登录流水号
	uint8_t iccid[ICCID_SIZE];																				//SIM中ICCID号
	uint8_t batterycnt;
	uint8_t batterycodesize;
	uint8_t batterycode[BATTERY_CNTMAX][BATTERY_CODEMAX];
	uint8_t bcc;
}cloudmsg_realtime_upload_t;

//实时信息上报格式
#define CLOUDMSG_REALTIME_UPLOAD_PACK(out, src, size)
struct _PACK_START cloudmsg_realtime_upload_t
{
	cloudtime_t curtime;
	nextmesg[0];					//变长结构体
	//uint8_t report[1];	//信息类型标志
	//can dup						信息体
	//type2	(信息类型标志)
	//dat2							信息体
}cloudmsg_readtime_upload_t;

//信息类型标志
typedef enum
{
	REPORT_FULLVEHICLE = 0x01,
	REPORT_MOTO = 0x02,
	REPORT_FUELCELL = 0x03,
	REPORT_ENGINE = 0x04,
	REPORT_LOADTION = 0x05,
	REPORT_ABSMAX = 0x06,
	REPORT_ALARM = 0x07,
	REPORT_USERDFI = 0x80
}vehicle_reporttype_t;

char *reportstr(vehicle_reporttype_t cmd);

//信息体
typedef struct _PACK_START
{
	uint8_t vehiclestate;								//车辆状态
	uint8_t chgstate;										//充电状态
	uint8_t runmode;										//运行模式
	uint16_t speed;											//车速
//speed = km/h
	uint32_t accumulationkms;						//累计行程
	uint16_t totalvol;									//总电压
//vol = V
	uint16_t totalcur;									//总电流	
//cur = A
	uint8_t SOCvalue;										//SOC
//0 -100 0xFE = ERR
	uint8_t dcdcstate;									//DC-DC状态
//
	uint8_t gearstate;									//档位
//
	uint8_t drvtap;											//绝缘电阻
	uint8_t breaktap;										//预留位
}cloudmsg_fullvehicleinfo_t;

#define MOTO_CNTMAX 4

#define CLOUDMSG_MOTOINFO_SIZE(msg) (msg.count * 12 + 1)

//每个驱动电机数据格式和定义
typedef struct _PACK_START
{
	uint8_t num;												//驱动电机序号
	uint8_t state;											//驱动电机状态
	uint16_t drivertemp;								//驱动电机控制器温度
	uint16_t speedrpm;									//驱动电机转速
//speed = rpm - 20000
	uint16_t torque;										//驱动电机转矩
//torque = N.M /10 - 20000
	uint8_t mototemp;										//驱动电机温度
	uint16_t drivervolin;								//电机控制器输入电压
//vol = V *10 100V -- 1000
	uint16_t drivercurin;								//电机控制器直流母线电流
}cloudmsg_motordetail_t;

//汽车电机数据格式和定义
#define CLOUDMSG_MOTOINFO_PACK cloudmsg_motorinfo_pack
typedef struct _PACK_START
{
	uint8_t count;
	cloudmsg_motordetail_t moto[MOTO_CNTMAX];
}cloudmsg_motorinfo_t;

void cloudmsg_motorinfo_pack(uint8_t *out, cloudmsg_motorinfo_t *src, uint16_t *size);

//燃料电池数据格式和定义
#define CLOUDMSG_FUELCELLINFO_PACK cloudmsg_fuelcellinfo_pack
#define BATERY_CNTMAX 4
typedef struct _PACK_START
{
	uint16_t vol;												//燃料电池电压
	uint16_t cur;												//燃料电池电流
	uint16_t reducerate;								//燃料消耗率
//reducerate = kg/100km * 100					
	uint16_t batterytempcnt;						//电池温度探针总数
	uint8_t batterytemp[BATERY_CNTMAX];	//探针温度值
//0-240max temp = C + 40		
	uint16_t hydrogenmaxtemp;						//氢系统中最高温度
	uint8_t istempval;									//氢系统中最高温度是否有效
	uint8_t hydrogenmaxtempid;					//氢系统中最高浓度
	uint8_t istempidval;								//氢系统中最高浓度是否有效
	uint16_t hydrogenmaxratio;					//氢气最高浓度
	uint8_t isratioval;									//氢气最高浓度是否有效
	uint8_t hydrogenmaxpressureid;			//氢气最高压力
	uint8_t ispressureidcal;						//氢气最高压力是否有效
	uint8_t highvoldcdcstate;						//高压DC/DC状态
}cloudmsg_fuelcellinfo_t;

//汽车发动机部分数据格式和定义
#define CLOUDMSG_ENGINEINFO_PACK(out, src, size)	(*size = sizeof(cloudmsg_engineinfo_t); \
memcpy(out, src, *size);)
typedef struct _PACK_START
{
	uint8_t state;											//发动机状态
	uint16_t speedrpm;									//曲轴转速
	uint16_t reducerate;								//燃料消耗率
}cloudmsg_engineinfo_t;

typedef struct
{
	uint8_t valid 	:1;							//定位状态
	uint8_t lat		:1;							//纬度
	uint8_t lon		:1;								//经度
	uint8_t backup	:5;							//备用
}direction;

#define CLOUDMSG_LOCATIONINFO_PACK(out, src, size)	\
				(size = sizeof(cloudmsg_loactioninfo_t); \
				memcpy(out, src, *size);)

typedef struct _PACK_START
{
	direction fixstate;							//定位状态
	uint32_t longitude;							//经度
	uint32_t latitude;							//纬度
}cloudmsg_locationinfo_t;

//极值数据
#define CLOUDMSG_ABSOLUTEMAXINFO_PACK(out, src, size)	\
				(*size = sizeof(cloudmsg_minmaxcellinfo_t);	\
				memcpy(out, src, *size);)
typedef struct _PACK_START
{
	uint8_t maxvolcellsysid;				//最高电压电池子系统号
	uint8_t maxvolcellid;						//最高电压电池单体代号
	uint16_t maxvolcellvalue;				//电池单体电压最高值
	uint8_t minvolcellsysid;				//最低电压电池子系统号
	uint8_t minvolcellid;						//最低电压电池单体代号
	uint16_t minvolcellvalue;				//电池单体电压最低值

	uint8_t maxtempcellsysid;				//最高温度子系统号
	uint8_t maxtempcellid;					//最高温度探针序号
	uint8_t maxtempcellvalue;				//最高温度值
	uint8_t mintempcellsysid;				//最低温度子系统号
	uint8_t mintempcellid;					//最低温度探针序号
	uint8_t mintempcellvalue;				//最低温度值
}cloudmsg_minmaxcellinfo_t;
/* 报警数据     ------> start */
typedef union{
	uint32_t AlarmFlag;
	struct{
		//uint32_t Backup								:9;			/*备用*/
		//uint32_t EnergyStorageDeviceOvercharge		:1;  		/*车载储能装置过充报警*/
		//uint32_t MicroShortCircuit					:1;	  		/*微短路报警*/
		//uint32_t BatteryLow							:1; 	  	/*蓄电池电量低报警*/
		//uint32_t WakeUp								:1;  		/*唤醒异常报警*/
		uint32_t TemperatureDiff					:1;	  		/*温度差异报警*/
		uint32_t BatteryHighTemperature				:1;  		/*电池高温报警*/
		uint32_t EnergyStorageDeviceTypeOvervoltage :1; 	  	/*车载储能装置类型过压报警*/
		uint32_t EnergyStorageDeviceTypeUndervoltage:1;	  		/*车载储能装置类型欠压报警*/
		uint32_t SOCLow								:1;  		/*SOC低报警*/
		uint32_t SingleBatteryOvervoltage 			:1; 	  	/*单体蓄电池过压报警*/
		uint32_t SingleBatteryUndervoltage 			:1;	  		/*单体蓄电池欠压报警*/
		uint32_t SOCHigh 							:1;  		/*SOC过高报警*/
		uint32_t SOCJump 							:1; 	  	/*SOC跳变报警*/
		uint32_t EnergyStorageMismatch				:1;	  		/*可充电储能系统不匹配报警*/
		uint32_t SingleCellConsistency				:1;  		/*单体电池一致性差报警*/
		uint32_t Insulation							:1; 	  	/*绝缘报警*/
		uint32_t DCDCTemperature					:1;		  	/*DCDC温度报警*/
		uint32_t BrakeSystem						:1;		  	/*制动系统报警*/
		uint32_t DCDCStatus							:1; 		/*DCDC状态报警*/
		uint32_t DriveMotorMontrollerTemperature	:1;	  		/*驱动电机控制器温度报警*/
		uint32_t HighVoltageInterlockState 			:1;  		/*高压互锁状态报警*/
		uint32_t DriveMotorTemperature				:1; 	  	/*驱动电机温度报警*/
		uint32_t EnergyStorageDeviceTypeOvercharge	:1;	  		/*车载储能装置类型过充报警*/
		uint32_t Backup								:13;		/*备用*/
	}AlarmFlagBit;
}generalAlarmInfo;


//报警数据
#define ALARM_MAXCNT 35
#define CLOUDMSG_ALARMINFO_PACK	cloudmsg_alarminfo_pack
typedef struct _PACK_START
{
	uint8_t maxalarmlevel;					//最高报警等级
	uint32_t commonalarmflag;				//通用报警标志

	uint8_t batteryalarmcnt;				//可充电储能装置故障总数 N1
	uint32_t batteryalarm[ALARM_MAXCNT];	//可充电储能装置故障代码列表

	uint8_t motoalarmcnt;									//驱动电机故障总数
	uint32_t motoalarm[ALARM_MAXCNT];			//驱动电机故障代码列表

	uint8_t enginealarmcnt;								//发动机故障总数 N3
	uint32_t enginealarm[ALARM_MAXCNT];		//发动机故障列表

	uint8_t otheralarmcnt;								//其他故障总数 N4
	uint32_t otheralarm[ALARM_MAXCNT];		//其他故障代码列表
}cloudmsg_alarminfo_t;

typedef struct _PACK_START
{
	uint8_t chargesystemcnt;		//可充电储能子系统个数
	uint8_t chargesystemnum;		//可充电储能子系统号
	uint16_t chargedevicevol;		//可充电储能装置电压
	uint16_t chargedevicecur;		//可充电储能装置电流
	uint16_t  signalcelltotalnum;	//单体电池总数
	uint16_t  IDRcellnum;			//本帧起始电池序号
	uint8_t IDRcelltotalnum;		//本帧单体电池总数
	uint8_t Signalcellvol[2*40];	//单体电池电压
}cloudmsg_chargevolinfo_t;

typedef struct _PACK_START
{
	uint8_t charge_nergysystemcnt;	//可充电储能子系统个数
	uint8_t charge_energysystemnum;	//可充电储能子系统号
	uint16_t charge_energy_temnum;	//可充电储能温度探针个数
	uint8_t charge_energy_tem[11];	//可充电储能子系统各温度探针检测到温度值

}cloudmsg_chargecurinfo_t;

void
cloudmsg_alarminfo_pack(uint8_t *out, cloudmsg_alarminfo_t *src,
        uint16_t *size);

//用户自定义数据
typedef struct _PACK_START
{
	uint16_t size;
	uint8_t dat[1];
}cloudmsg_userdefinfo_t;

//车辆登出
typedef struct _PACK_START
{
	cloudtime_t curtime;
	uint16_t seq;
}cloudmsg_vehicle_signout_t;

#define CLOUDMSG_REMOTECTL_SIZE(paramsize) 		(paramsize + 7)

#define CLOUDMSG_REMOTECTL_PARAMSIZEMAX		8

//远程控制
typedef struct _PACK_START
{
	cloudtime_t curtime;
	uint8_t type;
	uint8_t param[CLOUDMSG_REMOTECTL_PARAMSIZEMAX];
}cloudmsg_remotectl_t;

//平台登入数据格式和定义
typedef struct _PACK_START
{
	cloudtime_t curtime;
	uint16_t login_num;
	uint8_t username[12];
	uint8_t userpassword[20];
	uint8_t encry_rule;
}cloudplant_signindata;

//平台登出
typedef struct _PACK_START
{
	cloudtime_t curtime;
	uint16_t logout_num;
}cloudplant_signoutdata;


//bcc
uint8_t bccencryption(cloudpkg_t *);
//打包协议数据体
uint16_t pack_GBT32960DataBody(cloudcmd_t cmd, uint8_t *databuff, uint16_t buffsize, uint8_t *pInBuff, uint16_t len);
//打包车辆登录信息
uint16_t pack_GBT32960_VehiceLogin(uint8_t *, uint16_t);
//打包实时上报数据包
uint16_t pack_GBT32960_RealTimeInfoReport(uint8_t *, uint16_t);
//增加燃料电池数据s
uint16_t add_VehicleData(uint8_t *, uint16_t);

#if 1
typedef enum 
{
	GBT32960_RESPONSE_SUCCESS = 0x01,		//应答成功
	GBT32960_RESPONSE_ERROR = 0x02,			//设置未成功
	GBT32960_RESPONSE_REPEAT = 0x03,		//VIN重复
	GBT32960_RESPONSE_CMD = 0xFE,			//命令

	GBT32960_VehiceLoginID = 0x01,			//车辆登录
	GBT32960_RealTimeInfoReportID = 0x02, 	//实时信息上报
	GBT32960_ReissueInfoReportID = 0X03,	//补发信息上报
	GBT32960_VehiceLogoutID = 0X04,			//车辆登出
	GBT32960_PlatformLoginID = 0x05,		//平台登录
	GBT32960_PlatformLogoutID = 0x06,		//平台登出
	GB32960_HeartBeatID = 0x07,				//心跳
	GB32960_TerminalCalibrationTime = 0x08,	//终端校时

	GB32960_VehicleData = 0x01,				//整车数据
	GB32960_DriveMotorData = 0x02,			//驱动电机数据
	GB32960_FuelCellData = 0x03,			//燃料电池数据
	GB32960_EngineData = 0x04,				//发动机数
	GB32960_PositionInfoData = 0x05,		//位置信息数据
	GB32960_ExtremeValueData = 0x06,		//极值数据
	GB32960_AlarmData = 0x07,				//报警数据
	GB32960_RechargeableDevVoltage = 0x08,	//可充电储能装置电压数
	GB32960_RechargeableDevTemp = 0x09,		//可充电储能装置温度数

}cloudgbid_t;
#endif


#endif