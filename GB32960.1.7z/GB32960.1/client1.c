#include "GB32960.h"
#include "client.h"


//初始化socket
int socket_init(int *sockfd, int port, int time)
{
    if(NULL == sockfd)
        printf("the line:%d file:%s argument is failed\n",__LINE__,__FILE__);
//设置协议族
    struct sockaddr_in src = {0};
    src.sin_family = AF_INET;
    src.sin_port = htons(port);
#ifndef ENS
    src.sin_addr.s_addr = htonl("127.0.0.1");
#else
    src.sin_addr.s_addr = htonl("127.0.0.1");
#endif
//创建套接字
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    unsigned int addrsize = sizeof(src);
//绑定套接字
    if(0 > bind(sockfd, (struct sockaddr *)&src, addrsize)){
        printf("bind is failed! line:%d faile:%s\n",__LINE__,__FILE__);
        return 0;
    }
//监听套接字
    if(0 > listen(sockfd, 5)){
        printf("listen is error\n");
        return 0;
    }
//接受对面的socket
    struct sockaddr_in client_addrless = {0};
    socklen_t client_addrlength = sizeof(client_addrless);
    if(0 > accept(sockfd, (struct sockaddr*)&src, addrsize)){
        printf("accept is error\n");
        close(sockfd);
        return 0;
    }
    return sockfd;
}

//并发编程
int epoll_to_server()
{
    
}

//登录平台