#ifndef _COMMON_H_
#define _COMMON_H_

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

#ifndef DEBUG
    #define DEBUG 1
#endif

#if DEBUG
    #define DEBUGLOG(format,...) printf("### SYSLOG ### %s,%s[%d] "format"\n",__FILE__,__FUNCTION__,__LINE__,##__VA_ARGS__)
	#define DEBUG_NO(format,...) printf(format,##__VA_ARGS__)
#else
	#define DEBUGLOG(format,...)
	#define DEBUG_NO(format,...)
#endif

#ifndef GBT_DEBUG
	#define GBT_DEBUG 1
#endif

#if GBT_DEBUG
	#define GBTLOG(format,...) printf("### GBTLOG ### %s,%s [%d] "format"\n",__FILE__,__FUNCTION__,__LINE__,##__VA_ARGS__)
	//#define GBTLOG(format,...) printf("### GBTLOG ### %s [%d] "format"\n",__FUNCTION__,__LINE__,##__VA_ARGS__)
	#define GBT_NO(format,...) printf(format,##__VA_ARGS__)
#else

	#define GBTLOG(format,...)
	#define GBT_NO(format,...)
#endif

#endif