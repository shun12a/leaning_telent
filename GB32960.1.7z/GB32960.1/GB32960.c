#include "GB32960.h"
#include "common.h"

/*****************************************************************************
* Function Name : add_FuelCellData
* Description   : 增加燃料电池数据
* Input			: uint8_t *dataBuff           
*                 uint16_t buffSize
* Output        : None
* Return        : uint16_t 数据长度
* Auther        : xz
* Date          : 2022.11.14
*****************************************************************************/
uint16_t add_VehicleData(uint8_t *dataBuff, uint16_t buffSize)
{
    int i = 0;
    uint8_t *pos = dataBuff;
    cloudmsg_fullvehicleinfo_t pst;

    *pos++ = GB32960_VehicleData;
    *pos++ = GB32960_FuelCellData;
	*pos++ = pst.vehiclestate;					//*车辆状态
    *pos++ = pst.chgstate;                      //*充电状态
    *pos++ = pst.runmode;						//*运行模式
    if(2 == pst.vehiclestate)                   //*熄火    
    {
        pst.speed = 0;
    }
    *pos++ = (pst.vehiclestate >> 8)&0xff;		//*车速
    *pos++ = (pst.vehiclestate >> 0)&0xff;

    *pos++ = (pst.accumulationkms >>24)&0xff;	//*里程*/
    *pos++ = (pst.accumulationkms >>16)&0xff;
    *pos++ = (pst.accumulationkms >>8)&0xff;
    *pos++ = (pst.accumulationkms >>0)&0xff;

    *pos++ = (pst.totalvol >> 8)&0xff;          //*总电压
    *pos++ = (pst.totalvol >> 0)&0xff;

    *pos++ = (pst.totalcur >> 8)&0xff;          //*总电流
    *pos++ = (pst.totalcur >> 8)&0xff;

    
}

/*****************************************************************************
 * Function Name : bccencryption
 * Description   : BCC校验
 * Input			: uint8_t cmd
 *
 *
 * Output        : None
 * Return        : uint8_t 数据长度
 * Auther        : xz
 * Date          : 2022.11.14
 *****************************************************************************/
uint8_t bccencryption(void *str)
{
    if (NULL == str)
    {
        printf("argument is failed  %d, %s", __LINE__, __FILE__);
    }
    uint8_t lok = 0, cip = 0;
    uint8_t *crp = (uint8_t *)str;
    lok = sizeof(cloudpkg_t) / sizeof(uint8_t);
    if (lok < 4)
    {
        printf("Not need to BCC\n");
    }
    else
    {
        cip = *(crp + 2);
        for (int i = 0; i < lok - 3; i++)
        {
            cip ^= *(crp + 3 + i);
        }
    }
    return cip;
}

/*****************************************************************************
 * Function Name : pack_GBT32959_VehiceLogin
 * Description   : 打包车辆登录信息
 * Input			: uint8_t *dataBuff
 *                 uint16_t buffSize
 * Output        : None
 * Return        : uint16_t 数据长度
 * Auther        : xz
 * Date          : 2022.11.14
 *****************************************************************************/
uint16_t pack_GBT32960_VehiceLogin(uint8_t *dataBuff, uint16_t buffSize)
{
    cloudmsg_realtime_upload_t p_GBT32960_vehicalin;
    cloudmsg_realtime_upload_t *p_GBT32960_handle = &p_GBT32960_vehicalin;

    uint8_t i;
    uint8_t *pos = dataBuff;

    struct tm *p_tm = NULL;
    time_t tmp_time;
    tmp_time = time(NULL);
    p_tm = gmtime(&tmp_time);
    GBTLOG("TIME:%0d-%d-%d:%02d:%02d:%02d", p_tm->tm_year + 1900, p_tm->tm_mon, p_tm->tm_mday, p_tm->tm_hour, p_tm->tm_min, p_tm->tm_sec);

    // time
    *pos++ = p_tm->tm_year - 100;
    *pos++ = p_tm->tm_mon + 1;
    *pos++ = p_tm->tm_mday;
    *pos++ = p_tm->tm_hour;
    *pos++ = p_tm->tm_min;
    *pos++ = p_tm->tm_sec;

    *pos++ = (p_GBT32960_vehicalin.seq >> 8) & 0xFF;
    *pos++ = (p_GBT32960_vehicalin.seq >> 0) & 0xFF;
    GBTLOG("GBT32960 serialNumber:%d", p_GBT32960_vehicalin.seq);

    GBTLOG("GBT32960 ICCID:%s,ICCID Len:%d", p_GBT32960_handle->iccid, sizeof(p_GBT32960_handle->iccid));
    memcpy(pos, p_GBT32960_handle->iccid, sizeof(p_GBT32960_handle->iccid));
    pos += sizeof(p_GBT32960_handle->iccid);

    if (p_GBT32960_handle->batterycnt > BATTERY_CODEMAX)
        p_GBT32960_handle->batterycnt = BATTERY_CODEMAX;
    *pos++ = p_GBT32960_handle->batterycnt;

    if (p_GBT32960_handle->batterycodesize > BATTERY_CNTMAX)
        p_GBT32960_handle->batterycodesize = BATTERY_CNTMAX;
    *pos++ = p_GBT32960_handle->batterycodesize;

    GBTLOG("rechargeableEnergyLen:%d,rechargeableEnergyNum:%d", p_GBT32960_handle->batterycodesize,
           p_GBT32960_handle->batterycnt);

    if (p_GBT32960_handle->batterycnt != 0)
    {
        for (i = 0; i < p_GBT32960_handle->batterycnt; i++)
        {
            GBTLOG();
            memcpy(pos, &p_GBT32960_handle->batterycode[i][0], p_GBT32960_handle->batterycodesize);
            pos += p_GBT32960_handle->batterycodesize;
        }
    }
    return (uint16_t)(pos-dataBuff);
}

/*****************************************************************************
* Function Name : pack_GBT32960_RealTimeInfoReport
* Description   : 打包实时上报数据包
* Input			: uint8_t *dataBuff           
*                 uint16_t buffSize
* Output        : None
* Return        : uint16_t 数据长度
* Auther        : xz
* Date          : 2022.11.14
*****************************************************************************/
uint16_t pack_GBT32960_RealTimeInfoReport(uint8_t *dataBuff, uint16_t buffSize)
{
    uint8_t *pos = dataBuff;
	uint16_t dataLen = 0;
	uint16_t offset;
    reissue = false;
	struct tm *p_tm = NULL;
	time_t tmp_time;
	tmp_time = time(NULL);
	p_tm = gmtime(&tmp_time);
	GBTLOG("TIME:%0d-%d-%d:%02d:%02d:%02d",p_tm->tm_year+1900, p_tm->tm_mon,p_tm->tm_mday, p_tm->tm_hour,p_tm->tm_min,p_tm->tm_sec);
	printf("[ TIME is :%0d-%d-%d:%02d:%02d:%02d ]\n",p_tm->tm_year+1900,p_tm->tm_mon,p_tm->tm_mday, p_tm->tm_hour   \
            ,p_tm->tm_min,p_tm->tm_sec);

    //time
	*pos++ = p_tm->tm_year - 100;
	*pos++ = p_tm->tm_mon + 1;
	*pos++ = p_tm->tm_mday;
	*pos++ = p_tm->tm_hour;
	*pos++ = p_tm->tm_min;
	*pos++ = p_tm->tm_sec;

    //整车数据0x01
	offset = pos-dataBuff;
	GBTLOG("pos:%x,pos+offset=%x,offset:%d\n", pos,(pos+offset),offset);	
	if((dataLen = add_VehicleData(pos, buffSize-offset)) == 0)
	{
		GBTLOG("add_VehicleData error!");
		return 0;
	}
	pos += dataLen;
}

/*****************************************************************************
 * Function Name : pack_GBT32960DataBody
 * Description   : 打包协议数据体
 * Input			: uint8_t cmd
 *                 uint8_t *dataBuff
 *                 uint16_t buffSize
 *                 uint8_t *pInBuff
 *                 uint16_t len
 * Output        : None
 * Return        : uint16_t 数据长度
 * Auther        : xz
 * Date          : 2022.11.14
 *****************************************************************************/
uint16_t pack_GBT32960DataBody(cloudcmd_t cmd, uint8_t *databuff, uint16_t buffSize, uint8_t *pInBuff, uint16_t len)
{
    uint16_t dataLen = 0;
    switch (cmd)
    {
        //车辆登入
    case CMD_VEH_SIGNIN:
        dataLen = pack_GBT32960_VehiceLogin(databuff, buffSize);
        break;
        //实时信息上报
    case CMD_RT_UPLOAD:
        GBTLOG("GBT32960 Real-time reporting\n");
        //dataLen = pack_GBT32960_RealTimeInfoReport(dataBuff, buffSize);
        break;
        //平台登入
    case CMD_PLT_SIGNIN:

        break;
        //维护平台注册
    case CMD_PLT_SIGNOUT:

        break;
        //参数和状态查询
    case CMD_ARGUMENT_STATUE_QUERY:

        break;
        //设置参数
    case CMD_SET_ARGUMENT:

        break;
        //终端状态上报
    case CMD_STATE_UP:

        break;
        //车载终端控制
    case CMD_VEH_CONTROL:

        break;
    }
    return 0;
}
